% %%% Thesis
% %%% Ratio Sequence V_1
% %%% Load and save 340 nm image sequence
function [D340,D380,numCycles,numFrames340,fpc]=get_images
fpc=100; % frames per cycle
[filename, pathname] = uigetfile('*.tif','Select the 340nm first image');
if filename~=0
    D340 = dir(strcat([pathname, '*.tif']));
    numFrames340=size(D340);
    h1 = waitbar(0,'Loading...');
    for i=1:1:numFrames340(1)
%         nim=strcat(pathname,D340(i).name)
        waitbar(i/numFrames340(1))    
    end
    close(h1);
end

[filename, pathname] = uigetfile('*.tif','Select the 380nm first image');
if filename~=0
    D380 = dir(strcat([pathname, '*.tif']));
    numFrames380=size(D380);
    h1 = waitbar(0,'Loading...');
    for i=1:1:numFrames380(1)
%         nim=strcat(pathname,D380(i).name)
        waitbar(i/numFrames380(1))    
    end
    close(h1);
end

if(numFrames340==numFrames380)
    h1 = waitbar(0,'Series parsing test ...');
    for i=1:1:numFrames340(1)
        name340=D340(i).name;
        name380=D380(i).name;
        if(strcmp(name340(5:length(name340)),name380(5:length(name340)))==0)
            message=strcat('Name missmatch was found, please check the series. ',D340(i).name,'- and -',D380(i).name);
            errordlg(message,'Error')
            break
        end
        waitbar(i/numFrames340(1)) 
    end
    close(h1);
%     message='Series matched successfully'
    if (floor(mod(numFrames340(1),fpc))==0)
        numCycles = 1;
    else
        numCycles=floor(numFrames340(1)/fpc+1);
    end
    numFrames340=numFrames340(1);
else
    errordlg('Number of frames missmatch.','Error')
end